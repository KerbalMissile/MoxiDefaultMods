local UEHelpers = require("UEHelpers")

local TOGGLE_KEY = Key.X
local TOGGLE_MODIFIERS = {}
local ZOOM_POLL_MS = 16
local ZOOM_STEP = 50.0
local ZOOM_INTERP_ALPHA = 0.18
local ZOOM_SNAP_THRESHOLD = 0.5
local MIN_CAMERA_OFFSET = 15.0
local MAX_CAMERA_OFFSET = 1200.0
local MOUSE_WHEEL_AXIS_KEY = { KeyName = FName("MouseWheelAxis") }
local MOUSE_SCROLL_UP_KEY = { KeyName = FName("MouseScrollUp") }
local MOUSE_SCROLL_DOWN_KEY = { KeyName = FName("MouseScrollDown") }
local CachedPlayerController = nil
local CachedPawn = nil
local ZoomEnabled = false
local TargetCameraOffset = nil

local function IsValid(Object)
    return Object and Object:IsValid()
end

local function Clamp(Value, Min, Max)
    if Value < Min then
        return Min
    elseif Value > Max then
        return Max
    end

    return Value
end

local function Lerp(StartValue, EndValue, Alpha)
    return StartValue + ((EndValue - StartValue) * Alpha)
end

local function GetPlayerController()
    local PlayerController = UEHelpers.GetPlayerController()
    if IsValid(PlayerController) then
        return PlayerController
    end

    PlayerController = FindFirstOf("SN2PlayerController")
    if IsValid(PlayerController) then
        return PlayerController
    end

    return nil
end

local function CachePlayerObjects(PlayerController)
    CachedPlayerController = PlayerController
    CachedPawn = nil

    if PlayerController and IsValid(PlayerController.Pawn) then
        CachedPawn = PlayerController.Pawn
    end
end

local function WasInputKeyJustPressed(PlayerController, InputKey)
    local Success, WasPressed = pcall(function()
        return PlayerController:WasInputKeyJustPressed(InputKey)
    end)

    return Success and WasPressed == true
end

local function GetInputAnalogKeyState(PlayerController, InputKey)
    local Success, Value = pcall(function()
        return PlayerController:GetInputAnalogKeyState(InputKey)
    end)

    if not Success then
        return 0.0
    end

    return tonumber(Value) or 0.0
end

local function GetMouseWheelDelta(PlayerController)
    local WheelDelta = GetInputAnalogKeyState(PlayerController, MOUSE_WHEEL_AXIS_KEY)
    if WheelDelta ~= 0.0 then
        return WheelDelta
    end

    if WasInputKeyJustPressed(PlayerController, MOUSE_SCROLL_UP_KEY) then
        return 1.0
    elseif WasInputKeyJustPressed(PlayerController, MOUSE_SCROLL_DOWN_KEY) then
        return -1.0
    end

    return 0.0
end

local function ReturnToFirstPerson(PlayerController)
    local Success = pcall(function()
        PlayerController:ToggleThirdPerson()
    end)

    if Success then
        ZoomEnabled = false
        TargetCameraOffset = nil
    end
end

local function UpdateThirdPersonCamera()
    if not ZoomEnabled or CachedPlayerController == nil then
        return
    end

    if not IsValid(CachedPlayerController) then
        CachedPlayerController = nil
        CachedPawn = nil
        ZoomEnabled = false
        TargetCameraOffset = nil
        return
    end

    if not IsValid(CachedPawn) then
        CachePlayerObjects(CachedPlayerController)
    end

    if not IsValid(CachedPawn) or CachedPlayerController.CurrentPerspective ~= 1 then
        ZoomEnabled = false
        TargetCameraOffset = nil
        return
    end

    local WheelDelta = GetMouseWheelDelta(CachedPlayerController)
    if WheelDelta == 0.0 and TargetCameraOffset == nil then
        return
    end

    local CameraOffset = tonumber(CachedPlayerController.CameraOffset) or 0.0

    if TargetCameraOffset == nil then
        TargetCameraOffset = CameraOffset
    end

    if WheelDelta ~= 0.0 then
        local NewTargetCameraOffset = TargetCameraOffset - (WheelDelta * ZOOM_STEP)
        if NewTargetCameraOffset < MIN_CAMERA_OFFSET then
            ReturnToFirstPerson(CachedPlayerController)
            return
        end

        TargetCameraOffset = Clamp(NewTargetCameraOffset, MIN_CAMERA_OFFSET, MAX_CAMERA_OFFSET)
    end

    if TargetCameraOffset == CameraOffset then
        TargetCameraOffset = nil
        return
    end

    local NewCameraOffset = Lerp(CameraOffset, TargetCameraOffset, ZOOM_INTERP_ALPHA)
    if math.abs(NewCameraOffset - TargetCameraOffset) < ZOOM_SNAP_THRESHOLD then
        NewCameraOffset = TargetCameraOffset
        TargetCameraOffset = nil
    end

    CachedPlayerController.CameraOffset = Clamp(NewCameraOffset, MIN_CAMERA_OFFSET, MAX_CAMERA_OFFSET)
end

local function ToggleThirdPerson()
    local PlayerController = GetPlayerController()
    if not PlayerController then
        return
    end

    if not IsValid(PlayerController.Pawn) then
        return
    end

    local Success = pcall(function()
        PlayerController:ToggleThirdPerson()
    end)

    if not Success then
        return
    end

    CachePlayerObjects(PlayerController)
    TargetCameraOffset = tonumber(PlayerController.CameraOffset) or 0.0
    ZoomEnabled = PlayerController.CurrentPerspective == 1
end

if #TOGGLE_MODIFIERS > 0 then
    if not IsKeyBindRegistered(TOGGLE_KEY, TOGGLE_MODIFIERS) then
        RegisterKeyBind(TOGGLE_KEY, TOGGLE_MODIFIERS, function()
            ExecuteInGameThread(ToggleThirdPerson)
        end)
    end
elseif not IsKeyBindRegistered(TOGGLE_KEY) then
    RegisterKeyBind(TOGGLE_KEY, function()
        ExecuteInGameThread(ToggleThirdPerson)
    end)
end

LoopInGameThreadWithDelay(ZOOM_POLL_MS, UpdateThirdPersonCamera)
