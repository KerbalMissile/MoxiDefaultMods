local UEHelpers = require("UEHelpers")

local MOD_NAME = "Lifepod Uplink"

local MANIFEST_PATH = "./ue4ss/Mods/SN2ModSettings/registrations/LifepodUplink.lua"

local function write_text(path, body)
    local dir = path:match("(.*[/\\])")
    os.execute('mkdir "' .. dir:gsub("/", "\\") .. '" 2>nul')
    local f = io.open(path, "w")
    if not f then return false end
    f:write(body); f:close()
    return true
end

local manifest = [=[
return {
    name     = "LifepodUplink",
    display  = "Lifepod Uplink",
    settings = {
	{ 
	    key="Fabricator", title="Open Fabricator",
	    type="keybind", default="F"
	},
	{ 
	    key="Storage", title="Open Storage",
	    type="keybind", default="G"
	},
    },
}
]=]

write_text(MANIFEST_PATH, manifest)

local Config = {
    Fabricator = "F",
    Fabricator_Alt = "",
    Storage = "G",
    Storage_Alt = "",
}

local function LoadFromShared()
    if not ModRef then
	return false
    end
    local changed = false
    for k in pairs(Config) do
	local v = ModRef:GetSharedVariable("SN2ModSettings/LifepodUplink/" .. k)
	if v ~= nil and type(v) == type(Config[k]) and Config[k] ~= v then
	    Config[k] = v
	    changed = true
	end
    end
    return changed
end

local function GetPlayer()
    local controller = UEHelpers.GetPlayerController()
    local pawn = controller.Pawn
    return controller, pawn
end

local function IsMenuOpen(controller)
    return controller.bShowMouseCursor == true
end

local function OpenFabricator()
    local controller, pawn = GetPlayer()
    if IsMenuOpen(controller) then return end
    local fabricator = FindFirstOf("BP_Fabricator_Lifepod_C")
    fabricator.CrafterComponent.AllowedRecipesOverride = {}
    fabricator:InteractClient(controller, pawn, nil)
end

local function OpenStorage()
    local controller, pawn = GetPlayer()
    if IsMenuOpen(controller) then return end
    local locker = FindFirstOf("BP_LifepodWallLocker_C")
    local interaction = locker.InventoryInteraction
    interaction:SetInventoryInteractionEnabled(true)
    interaction:InteractWithInventoryInteractionComponent(controller, pawn, nil)
end

local keyMap = {
    A = Key.A, B = Key.B, C = Key.C, D = Key.D, E = Key.E,
    F = Key.F, G = Key.G, H = Key.H, I = Key.I, J = Key.J,
    K = Key.K, L = Key.L, M = Key.M, N = Key.N, O = Key.O,
    P = Key.P, Q = Key.Q, R = Key.R, S = Key.S, T = Key.T,
    U = Key.U, V = Key.V, W = Key.W, X = Key.X, Y = Key.Y, Z = Key.Z,
    F1 = Key.F1, F2 = Key.F2, F3 = Key.F3,  F4 = Key.F4,
    F5 = Key.F5, F6 = Key.F6, F7 = Key.F7,  F8 = Key.F8,
    F9 = Key.F9, F10 = Key.F10, F11 = Key.F11, F12 = Key.F12,
}

for keyName, keyConst in pairs(keyMap) do
    local captured_name = keyName
    RegisterKeyBind(keyConst, function()
	ExecuteInGameThread(function()
	    LoadFromShared()
	    if captured_name == Config.Fabricator
		or (Config.Fabricator_Alt ~= "" and captured_name == Config.Fabricator_Alt) then
		OpenFabricator()
		return
	    end
	    if captured_name == Config.Storage
		or (Config.Storage_Alt ~= "" and captured_name == Config.Storage_Alt) then
		OpenStorage()
		return
	    end
	end)
    end)
end