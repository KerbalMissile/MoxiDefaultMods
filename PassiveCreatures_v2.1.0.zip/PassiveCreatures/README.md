# PassiveCreatures for Subnautica 2

A UE4SS Lua mod that makes creatures non-aggressive toward you and your vehicles. Recreates the "peaceful" play experience the original Subnautica's `invisible` console command offered — and extends it to vehicles, which `invisible` never covered.

If you want to explore Subnautica 2 without being hunted, this is for you.

## Requirements

- **Subnautica 2** (early access).
- **UE4SS** installed. Nexus: https://www.nexusmods.com/subnautica2/mods/36
- *(Optional)* **SN2ModSettings** — for the in-game settings UI. Nexus: https://www.nexusmods.com/subnautica2/mods/20

Without SN2ModSettings the mod still works at defaults; you just won't get the slider UI to flip the "vehicles always passive" option. Ctrl+Shift+T toggles the master switch either way.

## Install

1. Make sure UE4SS is installed and working. Verify by launching SN2 — the UE4SS console window should appear alongside the game.
2. Extract this archive. Copy the `PassiveCreatures` folder into:
   `<your SN2 install>\Subnautica2\Binaries\Win64\ue4ss\Mods\`
3. (Steam default path: `C:\Program Files (x86)\Steam\steamapps\common\Subnautica2\Subnautica2\Binaries\Win64\ue4ss\Mods\`)
4. Launch the game and load a save. Creatures will ignore you.

The mod auto-loads via the included `enabled.txt` marker — no edits to `mods.txt` required.

## Usage

Passive mode is **on by default** when the game starts. A short on-screen toast confirms the state when the mod loads, and again every time you press the toggle key. The toast shows both states at once: green `Player: ON / Vehicles: ON` when everything is invisible; amber when anything is exposed.

| Action            | Keybind        |
| ----------------- | -------------- |
| Toggle master on/off | Ctrl+Shift+T |
| Manually re-apply | Ctrl+Shift+B   |

### Settings (with SN2ModSettings installed)

The settings UI exposes two toggles:

- **Passive mode** — the master switch (same thing Ctrl+Shift+T flips).
- **Vehicles always passive** — when ON, vehicles stay invisible to predators even with the master switch OFF. This is the "let predators chase me on foot but never attack my sub" mode.

Changes from the settings UI apply within a second; you don't need to reload or re-equip anything.

Console (optional): type `passive_status` in the in-game console (requires the ConsoleEnabler mod) to see both states.

The "manually re-apply" key is rarely needed — the mod re-applies automatically when you load a save, respawn, or enter a vehicle. Use it if you ever notice a creature targeting you when passive mode is supposed to be on.

## What it does

Predators in Subnautica 2 use Unreal Engine's standard AI perception system to detect targets. The mod makes you (and your vehicles) invisible to that system, so predators have nothing to react to: no chase, no attack, no damage. The visible behavior is that hostile creatures swim past you and go about their business.

This works against every creature that uses the perception system — which, as far as testing shows, is all of them.

## Known limitations

- **All creatures, not just hostiles.** Peaceful creatures also can't perceive you, which means schooling fish and other ambient AI may behave slightly differently around you (less flee, less follow). It's subtle but worth knowing.
- **Multiplayer: host-install only.** As of v2.1.0 the mod supports co-op, but only when installed on **the host**. SN2's perception system is host-authoritative, so a non-host client running the mod is harmless but ineffective. With the mod on the host, every connected player gets the protection — the host iterates all player pawns (its own + remote clients') and unregisters each from the creature perception system. Mid-session joiners are picked up automatically. Configs aren't synced automatically; all participants should share the same `PassiveCreatures.lua` saved file if you care about UI-state consistency. See `MULTIPLAYER.md` in the source tree for the full breakdown.
- **Story moments.** If a scripted story beat depends on a predator attacking you, that scene might stall. No known cases yet, but flag any you find.
- **Early access.** SN2 is patched frequently. If a patch breaks the mod, please report it — the fix is usually small.
- **No achievement guarantees.** SN2 doesn't currently ship achievements; if/when it does, this mod likely counts as a cheat.

## Troubleshooting

**Mod doesn't seem to be loaded.** Check the UE4SS console for `[PassiveCreatures] v2.1.0 loaded`, or look for the on-screen toast a few seconds after the game finishes loading. If you don't see it: confirm the folder path is exactly `<SN2>\Binaries\Win64\ue4ss\Mods\PassiveCreatures\` and that `enabled.txt` is inside that folder. Restart the game (or press Ctrl+R in-game to reload mods).

**Creatures are still attacking me.** Press Ctrl+Shift+T twice (toggles off and back on) to force a re-apply. If that doesn't work, press Ctrl+Shift+B. If still no change, see "Reporting issues" below.

**Game won't start.** Disable the mod by deleting the `enabled.txt` file from the `PassiveCreatures` folder, or remove the folder entirely. The mod doesn't modify game files — it only affects runtime behavior — so removing it returns the game to vanilla.

## Reporting issues

If something's not working, please include:

- Your SN2 build number (visible in the main menu).
- The UE4SS console output around the time of the issue.
- A description of what you expected vs. what happened.
- Whether you have other UE4SS mods installed.

## Uninstall

Delete the `PassiveCreatures` folder from `<SN2>\Binaries\Win64\ue4ss\Mods\`. Done.

## Credits

Built using [UE4SS](https://github.com/UE4SS-RE/RE-UE4SS) by the UE4SS team.

## Changelog

- **v2.1.0** — co-op support (host-install only). Host detects authority via `World:GetNetMode()` (with `PlayerController:HasAuthority` fallback), iterates every connected player's pawn via `FindAllOf("SN2PlayerCharacter")` and unregisters each from creature perception. Solo behavior is identical to v2.0.1; if host detection fails for any reason the code defaults to "treat as host" so solo players are never left unprotected. Non-host clients running the mod skip the apply path with a console log explaining why. Some MP behavior assumptions are documented as pending two-player verification — see `MULTIPLAYER.md` in the source tree.
- **v2.0.1** — fixed hotkey / settings-UI sync; reduced input lag.
- **v2.0.0** — SN2ModSettings integration, on-screen status toast.
- **v1.2.0** — dropped damage hooks (perception unregister covers the same ground without the C++ ceiling).

## License

Personal-use mod. Feel free to fork, modify, redistribute. Credit appreciated but not required.
