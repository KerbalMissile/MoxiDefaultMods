local MOD_NAME = "PassiveCreatures"
local VERSION = "2.1.0"

local config = require("config")
require("invisibility")        -- wraps config.toggle to re-apply
local notify = require("notify")  -- wraps the wrapped toggle to flash a toast
require("settings")            -- SN2ModSettings manifest + 1s polling

RegisterKeyBind(Key.T, {ModifierKey.CONTROL, ModifierKey.SHIFT}, config.toggle)

print(string.format("[%s] v%s loaded — Enabled=%s VehiclesAlwaysPassive=%s (toggle: Ctrl+Shift+T)\n",
    MOD_NAME, VERSION,
    tostring(config.Enabled), tostring(config.VehiclesAlwaysPassive)))

RegisterConsoleCommandHandler("passive_status", function(FullCommand, Parameters, OutputDevice)
    OutputDevice:Log(string.format("[%s] v%s — Enabled=%s VehiclesAlwaysPassive=%s",
        MOD_NAME, VERSION,
        tostring(config.Enabled), tostring(config.VehiclesAlwaysPassive)))
    return true
end)

-- Flash current state once the player is actually in-world. The PlayerController
-- exists on the main menu too, so polling for SN2PlayerCharacter (only spawned
-- when a save loads) avoids a confusing toast over the menu.
local POLL_INTERVAL_MS = 15000
local POLL_MAX_ATTEMPTS = 40  -- ~10 minutes at 15s/attempt
local function show_startup_toast_when_in_world(attempt)
    attempt = attempt or 1
    if attempt > POLL_MAX_ATTEMPTS then return end
    local p = FindFirstOf("SN2PlayerCharacter")
    local ok, valid = pcall(function() return p and p:IsValid() end)
    if ok and valid then
        -- Wait so the toast lands on a fully-rendered scene, not on the tail
        -- end of a black fade-out from the load screen.
        ExecuteWithDelay(3000, function() notify.show_status() end)
    else
        ExecuteWithDelay(POLL_INTERVAL_MS, function() show_startup_toast_when_in_world(attempt + 1) end)
    end
end
ExecuteWithDelay(2000, function() show_startup_toast_when_in_world() end)
