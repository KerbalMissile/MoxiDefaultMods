-- Make the player (and vehicles) invisible to UE's AI perception system by
-- unregistering their AIPerceptionStimuliSourceComponent. Predators using
-- sight or damage senses have no stimulus to react to — no targeting, no
-- attack, no damage.
--
-- SN2's UWEAIPerceptionComponent inherits from UE's AIPerceptionComponent
-- and uses the same stimuli-source system, so this works against both
-- vanilla and SN2-specific perception code.
--
-- Multiplayer (v2.1.0+):
--   The perception system runs on the authoritative side (server/host).
--   An unregister call from a non-host client modifies only the client's
--   local copy of the perception map, which has no AI consumer — the
--   server-side AI keeps perceiving the player and attacking. So apply()
--   is gated to host-only.
--
--   On the host, FindAllOf("SN2PlayerCharacter") returns every player's
--   pawn (host + connected clients, all server-spawned and authoritative
--   there). Iterating and unregistering each protects every connected
--   player. NotifyOnNewObject on the player class fires for mid-session
--   joiners on the host's side, so the host auto-applies invisibility to
--   late joiners without extra wiring.
--
--   Single-player is NM_Standalone — is_host() returns true, code path
--   is identical to v2.0.1.
--
-- See MULTIPLAYER.md / MULTIPLAYER_PLAN.md for the full host-authority
-- analysis and what needs co-op verification.

local MOD_NAME = "PassiveCreatures"
local config = require("config")
local UEHelpers = require("UEHelpers")

-- ── Host detection ────────────────────────────────────────────────────────────
--
-- Try UWorld:GetNetMode() first (returns ENetMode enum: 0=Standalone,
-- 1=DedicatedServer, 2=ListenServer — all authoritative; 3=Client — remote
-- only). Fall back to PlayerController:HasAuthority. If both detection paths
-- fail (UE4SS reflection quirk or world-not-ready), default to TRUE so a
-- solo player is never left unprotected by a broken API surface.
--
-- NEEDS 2-PLAYER VERIFICATION: confirm GetNetMode is reflected on UWorld in
-- SN2's UE 5.6 build and returns the expected enum values. If not, the
-- HasAuthority fallback should cover it; if THAT also fails, every player
-- gets treated as host (which means non-host clients run the apply path
-- harmlessly but ineffectively — same as v2.0.x behavior).
local function is_host()
    local world = nil
    pcall(function() world = UEHelpers.GetWorld() end)
    if world and world:IsValid() then
        local ok, mode = pcall(function() return world:GetNetMode() end)
        if ok and type(mode) == "number" then
            return mode ~= 3
        end
    end

    local pc = nil
    pcall(function() pc = UEHelpers:GetPlayerController() end)
    if pc and pc:IsValid() then
        local ok, has = pcall(function() return pc:HasAuthority() end)
        if ok and type(has) == "boolean" then
            return has
        end
    end

    print(string.format("[%s] WARN: host detection failed; assuming host\n", MOD_NAME))
    return true
end

-- ── Stimuli-source helpers ────────────────────────────────────────────────────

local function get_stimuli_source(actor)
    if not actor or not actor:IsValid() then return nil end
    local ok, comp = pcall(function() return actor.AIPerceptionStimuliSourceComponent end)
    if not ok or not comp then return nil end
    -- Reading a missing field returns wrapper userdata; IsValid distinguishes real from fake.
    local ok2, valid = pcall(function() return comp:IsValid() end)
    if not ok2 or not valid then return nil end
    return comp
end

local function unregister(actor)
    local comp = get_stimuli_source(actor)
    if not comp then return false end
    return pcall(function() comp:UnregisterFromPerceptionSystem() end)
end

local function register(actor)
    local comp = get_stimuli_source(actor)
    if not comp then return false end
    return pcall(function() comp:RegisterWithPerceptionSystem() end)
end

-- ── Pawn enumeration ──────────────────────────────────────────────────────────

-- In SP and on a host in co-op, FindAllOf("SN2PlayerCharacter") returns the
-- host's own pawn plus replicated pawns of every connected client (server-
-- authoritative there, since the host IS the server).
--
-- NEEDS 2-PLAYER VERIFICATION: confirm SN2 uses a single class for both
-- local and remote players in the host's view. In a 2-player co-op session,
-- the host running `print(#FindAllOf("SN2PlayerCharacter"))` should print 2.
-- If it prints 1, SN2 uses a separate class for the remote pawn (e.g.
-- SN2RemotePlayerCharacter, or maybe the base SN2BaseCharacter) — add it to
-- PLAYER_CLASSES below.
local PLAYER_CLASSES = {
    "SN2PlayerCharacter",
}

local function find_players()
    local out = {}
    local seen = {}
    for _, cls in ipairs(PLAYER_CLASSES) do
        local ok, list = pcall(function() return FindAllOf(cls) end)
        if ok and list then
            for _, p in ipairs(list) do
                if p and p:IsValid() then
                    local key = tostring(p)
                    if not seen[key] then
                        seen[key] = true
                        table.insert(out, p)
                    end
                end
            end
        end
    end
    return out
end

local VEHICLE_CLASSES = {
    "SN2PossessableVehicle",
    "SN2Submersible",
    "BP_Tadpole_C",
}

local function find_vehicles()
    local out = {}
    for _, cls in ipairs(VEHICLE_CLASSES) do
        local ok, list = pcall(function() return FindAllOf(cls) end)
        if ok and list then
            for _, v in ipairs(list) do
                if v and v:IsValid() then table.insert(out, v) end
            end
        end
    end
    return out
end

-- ── Apply ─────────────────────────────────────────────────────────────────────

local function apply()
    -- MP gate: the perception system is host-authoritative. Running this on a
    -- non-host client is harmless but ineffective — the unregister call only
    -- mutates the client's local proxy of the perception map, which has no
    -- AI consumer. Skip with a console log so the player can see why.
    if not is_host() then
        print(string.format("[%s] skipped — non-host client (perception is host-authoritative; install the mod on the host to protect everyone)\n", MOD_NAME))
        return
    end

    local player_op   = config.Enabled              and unregister or register
    local vehicle_op  = config.vehicles_invisible() and unregister or register

    local players = find_players()
    local p_ok = 0
    for _, p in ipairs(players) do
        if player_op(p) then p_ok = p_ok + 1 end
    end

    local vehicles = find_vehicles()
    local v_ok = 0
    for _, v in ipairs(vehicles) do
        if vehicle_op(v) then v_ok = v_ok + 1 end
    end

    print(string.format("[%s] applied — players: %d/%d (%s), vehicles: %d/%d (%s)\n",
        MOD_NAME,
        p_ok, #players, config.Enabled and "ON" or "OFF",
        v_ok, #vehicles, config.vehicles_invisible() and "ON" or "OFF"))
end

-- Manual re-apply (covers any edge case where the auto-apply missed something).
RegisterKeyBind(Key.B, {ModifierKey.CONTROL, ModifierKey.SHIFT}, apply)

-- Small delay so BeginPlay finishes and the stimuli component is registered first.
-- In co-op, this fires on the host whenever a remote player joins and their pawn
-- replicates in — apply() then picks them up via FindAllOf.
NotifyOnNewObject("/Script/Subnautica2.SN2PlayerCharacter", function() ExecuteWithDelay(500, apply) end)
NotifyOnNewObject("/Script/Subnautica2.SN2PossessableVehicle", function() ExecuteWithDelay(500, apply) end)

-- Hot-reload case: a save may already be loaded when the mod boots.
ExecuteWithDelay(2000, apply)

-- Wrap config.toggle so invisibility state follows the passive toggle.
local original_toggle = config.toggle
config.toggle = function()
    original_toggle()
    apply()
end

return {
    apply = apply,
}
