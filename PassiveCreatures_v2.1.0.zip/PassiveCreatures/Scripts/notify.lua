-- notify.lua — in-game text toast built from a runtime UMG widget.
-- KismetSystemLibrary.PrintString isn't visible in shipping builds, so we
-- construct a CanvasPanel + TextBlock and AddToViewport instead.

local UEHelpers = require("UEHelpers")

local M = {}

M.COLOR_DEFAULT = { R = 0.4, G = 0.85, B = 1.0, A = 1.0 }  -- cyan
M.COLOR_WARN    = { R = 1.0, G = 0.7,  B = 0.3, A = 1.0 }  -- amber
M.COLOR_OK      = { R = 0.4, G = 1.0,  B = 0.5, A = 1.0 }  -- green

local activeRoot = nil
local seq = 0

local function try(fn)
    local ok, r = pcall(fn)
    return ok and r or nil
end

-- Show a notification. opts:
--   duration = number (seconds, default 3.0)
--   color    = {R,G,B,A} table (default cyan)
function M.show(msg, opts)
    opts = opts or {}
    local duration = opts.duration or 3.0
    local color    = opts.color    or M.COLOR_DEFAULT

    if activeRoot then
        pcall(function() activeRoot:RemoveFromViewport() end)
        activeRoot = nil
    end

    local pc      = try(function() return UEHelpers:GetPlayerController() end)
    local wbLib   = StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary")
    local uwCls   = StaticFindObject("/Script/UMG.UserWidget")
    local canvCls = StaticFindObject("/Script/UMG.CanvasPanel")
    local textCls = StaticFindObject("/Script/UMG.TextBlock")
    if not (pc and wbLib and uwCls and canvCls and textCls) then return end

    seq = seq + 1
    local mySeq = seq

    local root
    pcall(function() root = wbLib:Create(pc, uwCls, pc) end)
    if not root then return end

    local function make(cls, name)
        local w
        pcall(function() w = StaticConstructObject(cls, root, FName("PC_" .. name .. mySeq)) end)
        return w
    end

    local canvas = make(canvCls, "Canvas")
    if not canvas then return end
    pcall(function() root.WidgetTree.RootWidget = canvas end)

    local txt = make(textCls, "Text")
    if not txt then return end
    pcall(function() txt:SetText(FText(tostring(msg))) end)
    pcall(function() txt:SetColorAndOpacity({ SpecifiedColor = color, ColorUseRule = 0 }) end)

    pcall(function()
        local slot = canvas:AddChildToCanvas(txt)
        if slot then
            slot:SetAnchors({ Minimum = { X = 0.5, Y = 0.10 }, Maximum = { X = 0.5, Y = 0.10 } })
            slot:SetAlignment({ X = 0.5, Y = 0.5 })
            slot:SetPosition({ X = 0, Y = 0 })
            slot:SetAutoSize(true)
        end
    end)

    pcall(function() root:AddToViewport(1000) end)
    activeRoot = root

    ExecuteWithDelay(math.floor(duration * 1000), function()
        ExecuteInGameThread(function()
            if activeRoot == root then
                pcall(function() root:RemoveFromViewport() end)
                activeRoot = nil
            end
        end)
    end)
end

local config = require("config")

-- Two-state badge: "Player: X / Vehicles: Y" with color reflecting whether
-- everything is invisible (green) or anything is exposed (amber).
function M.status_text_and_color()
    local p_on = config.Enabled
    local v_on = config.vehicles_invisible()
    local text = string.format("Player: %s / Vehicles: %s",
        p_on and "ON" or "OFF",
        v_on and "ON" or "OFF")
    local color = (p_on and v_on) and M.COLOR_OK or M.COLOR_WARN
    return text, color
end

function M.show_status()
    local text, color = M.status_text_and_color()
    M.show(text, { color = color })
end

-- Wrap config.toggle so each press flashes the new state on screen.
local original_toggle = config.toggle
config.toggle = function()
    original_toggle()
    M.show_status()
end

return M
