local M = {}

-- Field names match the SN2ModSettings manifest keys (settings.lua) so the
-- slider library can write straight into this table by key.
M.Enabled = true                  -- master switch: invisible to AI when true
M.VehiclesAlwaysPassive = false   -- when master is OFF, keep vehicles invisible anyway

M.MOD_NAME = "PassiveCreatures"

function M.toggle()
    M.Enabled = not M.Enabled
    print(string.format("[%s] passive mode: %s\n", M.MOD_NAME, M.Enabled and "ON" or "OFF"))
end

function M.vehicles_invisible()
    return M.Enabled or M.VehiclesAlwaysPassive
end

return M
