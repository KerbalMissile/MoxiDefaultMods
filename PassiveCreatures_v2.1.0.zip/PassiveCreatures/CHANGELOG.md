# Changelog

## v2.1.0 — co-op support (host-install only)

- **New:** the mod now protects *every* connected player in co-op, provided it's installed on the host. SN2's AI perception system is host-authoritative, so the host's unregister calls reach the server-side perception map that drives creature targeting. With v2.0.x, only the host player was protected (and only by accident — the code happened to iterate the local pawn, which on the host is the authoritative one). v2.1.0 makes this intentional and complete: the host iterates `FindAllOf("SN2PlayerCharacter")` and unregisters every player's pawn.
- **New:** host detection via `UWorld:GetNetMode()` with `PlayerController:HasAuthority` as a fallback. Non-host clients running the mod skip the apply path with a console log explaining why ("perception is host-authoritative; install the mod on the host to protect everyone"). No accidental client-side calls that could be confused with working.
- **Mid-session joiners:** the existing `NotifyOnNewObject` on the player class already fires when a remote player joins (their pawn replicates in on the host). No additional wiring needed — joiners auto-pick up invisibility.
- **Safety:** if host detection somehow fails (UE4SS reflection quirk, world not initialized), the code defaults to "treat as host" rather than "treat as client." Solo players are never silently left unprotected by a broken API surface.
- **No solo regression:** in single-player (`NM_Standalone`), `is_host()` returns true and the code path is byte-identical to v2.0.1.
- **Documentation:** see `MULTIPLAYER.md` and `MULTIPLAYER_PLAN.md` in the repo for the host-authority analysis. There are three assumptions in this release that need two-player in-game verification (NetMode API reflection, single player-class for all players, the basic premise that host-side unregister protects clients) — search the code for `NEEDS 2-PLAYER VERIFICATION` for the exact spots and what to test.
- **No automatic config sync:** all participants should share the same `PassiveCreatures.lua` saved file if they care about the in-game UI showing matching state. Building real RPC sync would require leaving the Lua layer; not in scope for v2.1.

## v2.0.1 — hotkey ↔ settings UI sync

- **Fixed:** Ctrl+Shift+T no longer gets reverted within ~1 second by the settings poller. The hotkey now writes through to SN2ModSettings (shared variable + saved file), so the polling loop sees a consistent state and bails. State also persists across game restarts via the saved file, the same as if you'd flipped it from the UI.
- **Fixed:** Ctrl+Shift+T no longer causes a visible frame hitch. Disk write was spawning `cmd.exe` for `mkdir` on every press; now lazy — only spawns the first time, if the directory doesn't exist.
- **New:** When the in-game settings panel is open, the "Passive mode" toggle visually flips in sync with the Ctrl+Shift+T hotkey. The mod finds the live widget and updates its Value directly. Previously the panel kept showing stale state until you closed and reopened it.
- No behavior changes for users who only flip the setting from the panel.

## v2.0.0 — SN2ModSettings integration, vehicles-always-passive toggle

- **Optional dep:** [SN2ModSettings](https://www.nexusmods.com/subnautica2/mods/20). Without it, the mod still works at defaults — Ctrl+Shift+T continues to flip the master toggle.
- New setting: **Vehicles always passive** — when ON, vehicles stay invisible to predators even with the master switch OFF. Use this when you want predators to chase you on foot but never attack your sub.
- Status toast and console output now show both states: `Player: ON / Vehicles: ON` (any combination). Green when both invisible; amber when anything is exposed.
- Internal: renamed `config.passive_enabled` → `config.Enabled` to match the SN2ModSettings naming convention. No user-visible change beyond field name.

## v1.2.0 — remove ineffective damage hooks

- Removed the three "belt-and-suspenders" hooks (`GetDamageMultiplier`, `GetAttackData`, `IsAttackTagEmpty`). Testing showed they weren't actually preventing damage; the perception-stimuli-source unregister in `invisibility.lua` is doing all the work on its own. Fewer moving parts, same in-game behavior.

## v1.1.0 — on-screen toggle feedback

- Added an in-game text toast that flashes the current passive mode state. Green "Passive: ON" / amber "Passive: OFF" appears at the top of the screen for 3 seconds whenever you press Ctrl+Shift+T, and once at game load so you know the mod is active.
- Implemented as a runtime UMG widget (`KismetSystemLibrary.PrintString` isn't visible in shipping builds).
- No gameplay changes from v1.0.0 — purely a UI addition.

## v1.0.0 — initial public release

- Player and vehicles are invisible to AI perception while passive mode is on.
- Ctrl+Shift+T toggles passive mode.
- Ctrl+Shift+B manually re-applies (rarely needed; auto-applies on save load and spawn).
- `passive_status` console command reports current state.
- Single-line diagnostic log on each apply (player and vehicle counts + current mode) so users can self-diagnose from the UE4SS log.
- Belt-and-suspenders hooks on `GetDamageMultiplier`, `GetAttackData`, and `IsAttackTagEmpty` catch any AI logic mid-decision when the toggle flips.
- Tested against Subnautica 2 early access build 34 (2026-05-19).
